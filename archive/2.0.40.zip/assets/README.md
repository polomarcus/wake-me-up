# The `src/assets` Directory

There's really not much to say here. Every file in this directory is recursively transferred to `dist/assets/`.

