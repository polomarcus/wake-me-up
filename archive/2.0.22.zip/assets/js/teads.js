	window._ttf = window._ttf || [];
	_ttf.push({
		  pid          : 22738
		  ,lang        : "fr"
		  ,slot        : '#chrono'
		  ,format      : "inread"
		  ,minSlot     : 0
		  ,BTF         : false
	});

	(function (d) {
		   var js, s = d.getElementsByTagName('script')[0];
		   js = d.createElement('script');
		   js.async = true;
		   js.src = 'http://cdn.teads.tv/js/all-v1.js';
		   s.parentNode.insertBefore(js, s);
	})(window.document);
